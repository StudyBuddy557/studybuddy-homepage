import { competitors } from '@/lib/competitor-data'; // 👈 Matches export
import Link from 'next/link';
import { ArrowRight, CheckCircle2 } from 'lucide-react';
import SalesBot from '@/components/chat/SalesBot';

export const metadata = {
  title: "Compare TEAS 7 Prep Courses | StudyBuddy",
  description: "See how StudyBuddy stacks up against NurseHub, ATI, and others.",
};

export default function CompareIndexPage() {
  return (
    <main className="min-h-screen bg-slate-50">
      <div className="bg-white border-b border-slate-200 py-20 px-4">
        <div className="max-w-4xl mx-auto text-center">
          <h1 className="text-4xl font-bold text-slate-900 mb-4">Compare StudyBuddy</h1>
          <p className="text-xl text-slate-600">
            See why thousands of nursing students are switching to AI-powered prep.
          </p>
        </div>
      </div>

      <div className="max-w-5xl mx-auto py-16 px-4">
        <div className="grid md:grid-cols-2 gap-6">
          {competitors.map((c) => (
            <Link 
              key={c.slug} 
              href={`/vs/${c.slug}`}
              className="group bg-white p-8 rounded-2xl border border-slate-200 shadow-sm hover:shadow-xl hover:border-teal-200 transition-all duration-300"
            >
              <div className="flex justify-between items-start mb-4">
                <div>
                   <h2 className="text-2xl font-bold text-slate-900 group-hover:text-teal-600 transition-colors">
                     vs {c.name}
                   </h2>
                   <p className="text-slate-500 text-sm mt-1">Compare features & pricing</p>
                </div>
                <div className="bg-slate-100 p-2 rounded-full group-hover:bg-teal-50 transition-colors">
                  <ArrowRight className="text-slate-400 group-hover:text-teal-500" />
                </div>
              </div>
              
              <div className="space-y-2">
                <div className="flex items-center gap-2 text-sm text-slate-600">
                   <CheckCircle2 size={16} className="text-teal-500" /> 
                   <span>StudyBuddy: {c.our_price}</span>
                </div>
                <div className="flex items-center gap-2 text-sm text-slate-400">
                   <div className="w-4 h-4 rounded-full border border-slate-300 flex items-center justify-center text-[10px]">vs</div>
                   <span>{c.name}: {c.their_price}</span>
                </div>
              </div>
            </Link>
          ))}
        </div>
      </div>
      <SalesBot />
    </main>
  );
}