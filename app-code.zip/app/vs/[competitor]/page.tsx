import { Metadata } from 'next';
import { notFound } from 'next/navigation';

// Define the data LOCALLY to prevent the "undefined" crash
const competitors = [
  {
    slug: 'nursehub',
    name: 'NurseHub',
    price: '$49.99/mo',
    features: ['Basic quizzes', 'Video lessons'],
    cons: 'Expensive monthly recurrence'
  },
  {
    slug: 'ati',
    name: 'ATI Official',
    price: '$80+',
    features: ['Official question bank'],
    cons: 'Very expensive, no explanations'
  },
  {
    slug: 'mometrix',
    name: 'Mometrix',
    price: '$29.99/mo',
    features: ['Book + Online'],
    cons: 'Text-heavy, boring interface'
  }
];

export async function generateStaticParams() {
  return competitors.map((c) => ({
    competitor: c.slug,
  }));
}

export const metadata: Metadata = {
  title: 'StudyBuddy vs Competitors',
  description: 'Compare TEAS 7 prep courses.',
};

export default function CompetitorPage({ params }: { params: { competitor: string } }) {
  const comp = competitors.find((c) => c.slug === params.competitor);

  if (!comp) {
    return notFound();
  }

  return (
    <div className="min-h-screen bg-white py-20 px-4">
      <div className="max-w-4xl mx-auto text-center">
        <h1 className="text-4xl font-bold text-slate-900 mb-6">
          StudyBuddy vs. {comp.name}
        </h1>
        <p className="text-xl text-slate-600 mb-12">
          Why students are switching from {comp.name} to AI-Powered Prep.
        </p>
        
        <div className="grid md:grid-cols-2 gap-8 text-left">
          {/* Competitor Card */}
          <div className="p-8 border border-slate-200 rounded-2xl bg-slate-50">
            <h3 className="text-2xl font-bold text-slate-500 mb-2">{comp.name}</h3>
            <p className="text-lg font-medium text-slate-900 mb-4">{comp.price}</p>
            <ul className="space-y-2 text-slate-600">
              <li className="text-red-500 font-medium">❌ {comp.cons}</li>
            </ul>
          </div>

          {/* StudyBuddy Card */}
          <div className="p-8 border-2 border-blue-600 rounded-2xl bg-white shadow-xl relative overflow-hidden">
             <div className="absolute top-0 right-0 bg-blue-600 text-white text-xs font-bold px-3 py-1 rounded-bl-lg uppercase">
               Winner
             </div>
            <h3 className="text-2xl font-bold text-blue-900 mb-2">StudyBuddy</h3>
            <p className="text-lg font-medium text-slate-900 mb-4">$24.99/mo</p>
            <ul className="space-y-2 text-slate-600">
              <li className="text-emerald-600 font-medium">✅ AI-Powered Custom Plans</li>
              <li className="text-emerald-600 font-medium">✅ 100% Pass Guarantee</li>
            </ul>
          </div>
        </div>
      </div>
    </div>
  );
}