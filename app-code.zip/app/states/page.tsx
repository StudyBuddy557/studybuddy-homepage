// app/states/[state]/page.tsx
import { notFound } from 'next/navigation';
import Link from 'next/link';
import Script from 'next/script';
import AIChat from '@/components/chat/AIChat';
import { Metadata } from 'next';

// ========================================
// 1. COMPLETE 50-STATE DATABASE WITH NURSING STATS
// ========================================
const stateDatabase: Record<string, {
  name: string;
  acceptanceRate: string;
  avgScore: number;
  cutoffScore: string;
  slug: string;
  colleges: string[];
  nursingStats: {
    rnAdequacy: string;
    shortage: string;
    jobGrowth: string;
    averageSalary: string;
  };
}> = {
  alabama: {
    name: 'Alabama',
    acceptanceRate: '67%',
    avgScore: 71.5,
    cutoffScore: '62',
    slug: 'alabama',
    colleges: ['UAB', 'Auburn', 'Univ. of Alabama', 'Samford', 'Troy University', 'Wallace State'],
    nursingStats: {
      rnAdequacy: '82%',
      shortage: '3,200 RN shortage by 2030',
      jobGrowth: '14% growth through 2030',
      averageSalary: '$63,000'
    }
  },
  alaska: {
    name: 'Alaska',
    acceptanceRate: '62%',
    avgScore: 70.8,
    cutoffScore: '64',
    slug: 'alaska',
    colleges: ['UAA', 'UAF', 'Alaska Pacific', 'Charter College'],
    nursingStats: {
      rnAdequacy: '75%',
      shortage: '450 RN shortage by 2030',
      jobGrowth: '16% growth through 2030',
      averageSalary: '$89,000'
    }
  },
  arizona: {
    name: 'Arizona',
    acceptanceRate: '65%',
    avgScore: 73.2,
    cutoffScore: '65',
    slug: 'arizona',
    colleges: ['Arizona State', 'Univ. of Arizona', 'Grand Canyon Univ', 'Northern Arizona', 'Maricopa CC', 'Pima CC'],
    nursingStats: {
      rnAdequacy: '79%',
      shortage: '5,800 RN shortage by 2030',
      jobGrowth: '18% growth through 2030',
      averageSalary: '$80,000'
    }
  },
  arkansas: {
    name: 'Arkansas',
    acceptanceRate: '70%',
    avgScore: 70.5,
    cutoffScore: '60',
    slug: 'arkansas',
    colleges: ['UAMS', 'Arkansas State', 'UCA', 'Univ. of Arkansas', 'Harding University'],
    nursingStats: {
      rnAdequacy: '84%',
      shortage: '2,400 RN shortage by 2030',
      jobGrowth: '13% growth through 2030',
      averageSalary: '$61,000'
    }
  },
  california: {
    name: 'California',
    acceptanceRate: '38%',
    avgScore: 78.4,
    cutoffScore: '70',
    slug: 'california',
    colleges: ['CSU Long Beach', 'UCLA', 'San Diego State', 'Cal State LA', 'Fullerton College', 'Saddleback College'],
    nursingStats: {
      rnAdequacy: '71%',
      shortage: '44,500 RN shortage by 2030',
      jobGrowth: '20% growth through 2030',
      averageSalary: '$124,000'
    }
  },
  colorado: {
    name: 'Colorado',
    acceptanceRate: '58%',
    avgScore: 74.5,
    cutoffScore: '66',
    slug: 'colorado',
    colleges: ['CU Anschutz', 'UNC', 'CSU Pueblo', 'Denver College of Nursing', 'Regis University', 'Pikes Peak CC'],
    nursingStats: {
      rnAdequacy: '81%',
      shortage: '4,200 RN shortage by 2030',
      jobGrowth: '15% growth through 2030',
      averageSalary: '$77,000'
    }
  },
  connecticut: {
    name: 'Connecticut',
    acceptanceRate: '55%',
    avgScore: 73.0,
    cutoffScore: '65',
    slug: 'connecticut',
    colleges: ['UConn', 'Southern CT State', 'Sacred Heart', 'Quinnipiac', 'Fairfield University'],
    nursingStats: {
      rnAdequacy: '86%',
      shortage: '2,100 RN shortage by 2030',
      jobGrowth: '9% growth through 2030',
      averageSalary: '$81,000'
    }
  },
  delaware: {
    name: 'Delaware',
    acceptanceRate: '60%',
    avgScore: 72.8,
    cutoffScore: '64',
    slug: 'delaware',
    colleges: ['Univ. of Delaware', 'Delaware State', 'Delaware Tech', 'Wilmington Univ'],
    nursingStats: {
      rnAdequacy: '83%',
      shortage: '800 RN shortage by 2030',
      jobGrowth: '12% growth through 2030',
      averageSalary: '$73,000'
    }
  },
  florida: {
    name: 'Florida',
    acceptanceRate: '65%',
    avgScore: 71.2,
    cutoffScore: '63',
    slug: 'florida',
    colleges: ['Univ. of Florida', 'Miami Dade', 'UCF', 'USF', 'Valencia College', 'Broward College'],
    nursingStats: {
      rnAdequacy: '76%',
      shortage: '59,100 RN shortage by 2030',
      jobGrowth: '22% growth through 2030',
      averageSalary: '$70,000'
    }
  },
  georgia: {
    name: 'Georgia',
    acceptanceRate: '69%',
    avgScore: 72.9,
    cutoffScore: '62',
    slug: 'georgia',
    colleges: ['Emory', 'Augusta Univ', 'Georgia State', 'Kennesaw State', 'Mercer', 'Gwinnett Tech'],
    nursingStats: {
      rnAdequacy: '80%',
      shortage: '9,500 RN shortage by 2030',
      jobGrowth: '17% growth through 2030',
      averageSalary: '$68,000'
    }
  },
  hawaii: {
    name: 'Hawaii',
    acceptanceRate: '50%',
    avgScore: 74.0,
    cutoffScore: '68',
    slug: 'hawaii',
    colleges: ['UH Manoa', 'UH Hilo', 'Hawaii Pacific', 'Chaminade', 'Kapiolani CC'],
    nursingStats: {
      rnAdequacy: '78%',
      shortage: '1,400 RN shortage by 2030',
      jobGrowth: '14% growth through 2030',
      averageSalary: '$98,000'
    }
  },
  idaho: {
    name: 'Idaho',
    acceptanceRate: '72%',
    avgScore: 71.8,
    cutoffScore: '62',
    slug: 'idaho',
    colleges: ['Boise State', 'Idaho State', 'Lewis-Clark State', 'CWI', 'North Idaho College'],
    nursingStats: {
      rnAdequacy: '77%',
      shortage: '2,600 RN shortage by 2030',
      jobGrowth: '19% growth through 2030',
      averageSalary: '$69,000'
    }
  },
  illinois: {
    name: 'Illinois',
    acceptanceRate: '63%',
    avgScore: 73.5,
    cutoffScore: '64',
    slug: 'illinois',
    colleges: ['UIC', 'Loyola Chicago', 'Chamberlain', 'Illinois State', 'Rush University', 'NIU'],
    nursingStats: {
      rnAdequacy: '85%',
      shortage: '10,200 RN shortage by 2030',
      jobGrowth: '11% growth through 2030',
      averageSalary: '$75,000'
    }
  },
  indiana: {
    name: 'Indiana',
    acceptanceRate: '70%',
    avgScore: 72.1,
    cutoffScore: '62',
    slug: 'indiana',
    colleges: ['Indiana University', 'Purdue', 'Ball State', 'Ivy Tech', 'Valparaiso'],
    nursingStats: {
      rnAdequacy: '82%',
      shortage: '6,400 RN shortage by 2030',
      jobGrowth: '13% growth through 2030',
      averageSalary: '$66,000'
    }
  },
  iowa: {
    name: 'Iowa',
    acceptanceRate: '74%',
    avgScore: 71.5,
    cutoffScore: '60',
    slug: 'iowa',
    colleges: ['Univ. of Iowa', 'Mount Mercy', 'St. Ambrose', 'Kirkwood CC', 'DMACC'],
    nursingStats: {
      rnAdequacy: '88%',
      shortage: '2,800 RN shortage by 2030',
      jobGrowth: '10% growth through 2030',
      averageSalary: '$62,000'
    }
  },
  kansas: {
    name: 'Kansas',
    acceptanceRate: '71%',
    avgScore: 71.9,
    cutoffScore: '61',
    slug: 'kansas',
    colleges: ['KU Medical Center', 'Wichita State', 'Washburn', 'Fort Hays State', 'JCCC'],
    nursingStats: {
      rnAdequacy: '84%',
      shortage: '3,100 RN shortage by 2030',
      jobGrowth: '12% growth through 2030',
      averageSalary: '$64,000'
    }
  },
  kentucky: {
    name: 'Kentucky',
    acceptanceRate: '73%',
    avgScore: 70.8,
    cutoffScore: '60',
    slug: 'kentucky',
    colleges: ['Univ. of Kentucky', 'Louisville', 'WKU', 'EKU', 'Morehead State'],
    nursingStats: {
      rnAdequacy: '81%',
      shortage: '4,700 RN shortage by 2030',
      jobGrowth: '14% growth through 2030',
      averageSalary: '$63,000'
    }
  },
  louisiana: {
    name: 'Louisiana',
    acceptanceRate: '68%',
    avgScore: 71.0,
    cutoffScore: '62',
    slug: 'louisiana',
    colleges: ['LSU Health', 'UL Lafayette', 'Southeastern Louisiana', 'Delgado CC', 'Northwestern State'],
    nursingStats: {
      rnAdequacy: '79%',
      shortage: '5,300 RN shortage by 2030',
      jobGrowth: '15% growth through 2030',
      averageSalary: '$66,000'
    }
  },
  maine: {
    name: 'Maine',
    acceptanceRate: '66%',
    avgScore: 72.5,
    cutoffScore: '63',
    slug: 'maine',
    colleges: ['Univ. of Maine', 'UNE', 'Husson', 'Saint Joseph\'s College'],
    nursingStats: {
      rnAdequacy: '85%',
      shortage: '1,500 RN shortage by 2030',
      jobGrowth: '11% growth through 2030',
      averageSalary: '$72,000'
    }
  },
  maryland: {
    name: 'Maryland',
    acceptanceRate: '58%',
    avgScore: 74.2,
    cutoffScore: '66',
    slug: 'maryland',
    colleges: ['UM School of Nursing', 'Towson', 'Johns Hopkins', 'Salisbury', 'Montgomery College'],
    nursingStats: {
      rnAdequacy: '83%',
      shortage: '5,600 RN shortage by 2030',
      jobGrowth: '13% growth through 2030',
      averageSalary: '$79,000'
    }
  },
  massachusetts: {
    name: 'Massachusetts',
    acceptanceRate: '52%',
    avgScore: 75.0,
    cutoffScore: '68',
    slug: 'massachusetts',
    colleges: ['UMass Boston', 'Northeastern', 'Simmons', 'MCPHS', 'Curry College'],
    nursingStats: {
      rnAdequacy: '87%',
      shortage: '6,200 RN shortage by 2030',
      jobGrowth: '10% growth through 2030',
      averageSalary: '$92,000'
    }
  },
  michigan: {
    name: 'Michigan',
    acceptanceRate: '64%',
    avgScore: 73.1,
    cutoffScore: '63',
    slug: 'michigan',
    colleges: ['Univ. of Michigan', 'Michigan State', 'Wayne State', 'Grand Valley State', 'Eastern Michigan'],
    nursingStats: {
      rnAdequacy: '82%',
      shortage: '10,800 RN shortage by 2030',
      jobGrowth: '14% growth through 2030',
      averageSalary: '$71,000'
    }
  },
  minnesota: {
    name: 'Minnesota',
    acceptanceRate: '67%',
    avgScore: 73.5,
    cutoffScore: '64',
    slug: 'minnesota',
    colleges: ['Univ. of Minnesota', 'Minnesota State', 'St. Catherine Univ', 'Winona State', 'Century College', 'Normandale CC'],
    nursingStats: {
      rnAdequacy: '86%',
      shortage: '5,400 RN shortage by 2030',
      jobGrowth: '12% growth through 2030',
      averageSalary: '$77,000'
    }
  },
  mississippi: {
    name: 'Mississippi',
    acceptanceRate: '75%',
    avgScore: 69.8,
    cutoffScore: '60',
    slug: 'mississippi',
    colleges: ['UMMC', 'Southern Miss', 'Mississippi College', 'William Carey', 'Hinds CC'],
    nursingStats: {
      rnAdequacy: '76%',
      shortage: '3,800 RN shortage by 2030',
      jobGrowth: '16% growth through 2030',
      averageSalary: '$60,000'
    }
  },
  missouri: {
    name: 'Missouri',
    acceptanceRate: '68%',
    avgScore: 72.4,
    cutoffScore: '62',
    slug: 'missouri',
    colleges: ['UMKC', 'Mizzou', 'Saint Louis Univ', 'Goldfarb', 'Missouri State'],
    nursingStats: {
      rnAdequacy: '83%',
      shortage: '6,900 RN shortage by 2030',
      jobGrowth: '13% growth through 2030',
      averageSalary: '$65,000'
    }
  },
  montana: {
    name: 'Montana',
    acceptanceRate: '70%',
    avgScore: 71.5,
    cutoffScore: '62',
    slug: 'montana',
    colleges: ['Montana State', 'Univ. of Montana', 'Carroll College', 'Montana Tech'],
    nursingStats: {
      rnAdequacy: '80%',
      shortage: '1,200 RN shortage by 2030',
      jobGrowth: '15% growth through 2030',
      averageSalary: '$67,000'
    }
  },
  nebraska: {
    name: 'Nebraska',
    acceptanceRate: '71%',
    avgScore: 72.0,
    cutoffScore: '62',
    slug: 'nebraska',
    colleges: ['UNMC', 'Creighton', 'Nebraska Methodist', 'Clarkson College'],
    nursingStats: {
      rnAdequacy: '85%',
      shortage: '2,200 RN shortage by 2030',
      jobGrowth: '11% growth through 2030',
      averageSalary: '$64,000'
    }
  },
  nevada: {
    name: 'Nevada',
    acceptanceRate: '60%',
    avgScore: 73.8,
    cutoffScore: '65',
    slug: 'nevada',
    colleges: ['UNLV', 'UNR', 'Nevada State', 'CSN', 'Truckee Meadows'],
    nursingStats: {
      rnAdequacy: '74%',
      shortage: '4,500 RN shortage by 2030',
      jobGrowth: '21% growth through 2030',
      averageSalary: '$82,000'
    }
  },
  'new-hampshire': {
    name: 'New Hampshire',
    acceptanceRate: '62%',
    avgScore: 73.2,
    cutoffScore: '64',
    slug: 'new-hampshire',
    colleges: ['UNH', 'SNHU', 'Rivier', 'St. Anselm', 'Colby-Sawyer'],
    nursingStats: {
      rnAdequacy: '84%',
      shortage: '1,600 RN shortage by 2030',
      jobGrowth: '12% growth through 2030',
      averageSalary: '$74,000'
    }
  },
  'new-jersey': {
    name: 'New Jersey',
    acceptanceRate: '55%',
    avgScore: 74.5,
    cutoffScore: '66',
    slug: 'new-jersey',
    colleges: ['Rutgers', 'Seton Hall', 'TCNJ', 'Kean University', 'Chamberlain NJ'],
    nursingStats: {
      rnAdequacy: '81%',
      shortage: '11,400 RN shortage by 2030',
      jobGrowth: '14% growth through 2030',
      averageSalary: '$82,000'
    }
  },
  'new-mexico': {
    name: 'New Mexico',
    acceptanceRate: '68%',
    avgScore: 71.0,
    cutoffScore: '62',
    slug: 'new-mexico',
    colleges: ['UNM', 'NMSU', 'CNM', 'Eastern New Mexico'],
    nursingStats: {
      rnAdequacy: '77%',
      shortage: '2,800 RN shortage by 2030',
      jobGrowth: '17% growth through 2030',
      averageSalary: '$70,000'
    }
  },
  'new-york': {
    name: 'New York',
    acceptanceRate: '64%',
    avgScore: 70.5,
    cutoffScore: '64',
    slug: 'new-york',
    colleges: ['NYU', 'Hunter College', 'Stony Brook', 'Adelphi', 'BMCC', 'Nassau CC'],
    nursingStats: {
      rnAdequacy: '84%',
      shortage: '21,300 RN shortage by 2030',
      jobGrowth: '12% growth through 2030',
      averageSalary: '$88,000'
    }
  },
  'north-carolina': {
    name: 'North Carolina',
    acceptanceRate: '62%',
    avgScore: 73.6,
    cutoffScore: '65',
    slug: 'north-carolina',
    colleges: ['UNC Chapel Hill', 'ECU', 'UNC Greensboro', 'Duke', 'Winston-Salem State', 'Wake Tech'],
    nursingStats: {
      rnAdequacy: '80%',
      shortage: '12,500 RN shortage by 2030',
      jobGrowth: '16% growth through 2030',
      averageSalary: '$67,000'
    }
  },
  'north-dakota': {
    name: 'North Dakota',
    acceptanceRate: '76%',
    avgScore: 70.2,
    cutoffScore: '60',
    slug: 'north-dakota',
    colleges: ['UND', 'NDSU', 'Univ. of Mary', 'Minot State'],
    nursingStats: {
      rnAdequacy: '87%',
      shortage: '900 RN shortage by 2030',
      jobGrowth: '10% growth through 2030',
      averageSalary: '$66,000'
    }
  },
  ohio: {
    name: 'Ohio',
    acceptanceRate: '73%',
    avgScore: 74.1,
    cutoffScore: '61',
    slug: 'ohio',
    colleges: ['Ohio State', 'Cincinnati', 'Kent State', 'Ohio Univ', 'Columbus State', 'Cuyahoga CC'],
    nursingStats: {
      rnAdequacy: '83%',
      shortage: '13,700 RN shortage by 2030',
      jobGrowth: '13% growth through 2030',
      averageSalary: '$68,000'
    }
  },
  oklahoma: {
    name: 'Oklahoma',
    acceptanceRate: '70%',
    avgScore: 71.8,
    cutoffScore: '61',
    slug: 'oklahoma',
    colleges: ['OU Health', 'UCO', 'Oklahoma City CC', 'Tulsa CC', 'SWOSU'],
    nursingStats: {
      rnAdequacy: '79%',
      shortage: '4,600 RN shortage by 2030',
      jobGrowth: '15% growth through 2030',
      averageSalary: '$63,000'
    }
  },
  oregon: {
    name: 'Oregon',
    acceptanceRate: '58%',
    avgScore: 75.2,
    cutoffScore: '68',
    slug: 'oregon',
    colleges: ['OHSU', 'Univ. of Portland', 'Linfield', 'Chemeketa CC', 'PCC'],
    nursingStats: {
      rnAdequacy: '82%',
      shortage: '4,900 RN shortage by 2030',
      jobGrowth: '14% growth through 2030',
      averageSalary: '$93,000'
    }
  },
  pennsylvania: {
    name: 'Pennsylvania',
    acceptanceRate: '61%',
    avgScore: 73.9,
    cutoffScore: '65',
    slug: 'pennsylvania',
    colleges: ['Penn State', 'Pitt', 'Villanova', 'Drexel', 'Duquesne', 'Temple'],
    nursingStats: {
      rnAdequacy: '85%',
      shortage: '14,200 RN shortage by 2030',
      jobGrowth: '12% growth through 2030',
      averageSalary: '$72,000'
    }
  },
  'rhode-island': {
    name: 'Rhode Island',
    acceptanceRate: '56%',
    avgScore: 74.1,
    cutoffScore: '66',
    slug: 'rhode-island',
    colleges: ['URI', 'RIC', 'Salve Regina', 'CCRI'],
    nursingStats: {
      rnAdequacy: '86%',
      shortage: '1,100 RN shortage by 2030',
      jobGrowth: '10% growth through 2030',
      averageSalary: '$79,000'
    }
  },
  'south-carolina': {
    name: 'South Carolina',
    acceptanceRate: '65%',
    avgScore: 72.3,
    cutoffScore: '63',
    slug: 'south-carolina',
    colleges: ['USC', 'Clemson', 'MUSC', 'Trident Tech', 'Greenville Tech'],
    nursingStats: {
      rnAdequacy: '78%',
      shortage: '6,700 RN shortage by 2030',
      jobGrowth: '17% growth through 2030',
      averageSalary: '$65,000'
    }
  },
  'south-dakota': {
    name: 'South Dakota',
    acceptanceRate: '72%',
    avgScore: 71.4,
    cutoffScore: '61',
    slug: 'south-dakota',
    colleges: ['SDSU', 'USD', 'Augustana', 'Presentation College'],
    nursingStats: {
      rnAdequacy: '84%',
      shortage: '1,000 RN shortage by 2030',
      jobGrowth: '12% growth through 2030',
      averageSalary: '$61,000'
    }
  },
  tennessee: {
    name: 'Tennessee',
    acceptanceRate: '68%',
    avgScore: 72.6,
    cutoffScore: '62',
    slug: 'tennessee',
    colleges: ['UT Knoxville', 'Belmont', 'MTSU', 'Union University', 'ETSU'],
    nursingStats: {
      rnAdequacy: '80%',
      shortage: '8,300 RN shortage by 2030',
      jobGrowth: '16% growth through 2030',
      averageSalary: '$64,000'
    }
  },
  texas: {
    name: 'Texas',
    acceptanceRate: '71%',
    avgScore: 73.8,
    cutoffScore: '62',
    slug: 'texas',
    colleges: ['UT Austin', 'Texas A&M', 'UT Arlington', 'Texas Tech', 'Houston CC', 'Alamo Colleges'],
    nursingStats: {
      rnAdequacy: '88%',
      shortage: '15,900 RN shortage by 2030',
      jobGrowth: '19% growth through 2030',
      averageSalary: '$73,000'
    }
  },
  utah: {
    name: 'Utah',
    acceptanceRate: '63%',
    avgScore: 73.0,
    cutoffScore: '64',
    slug: 'utah',
    colleges: ['Univ. of Utah', 'BYU', 'UVU', 'Weber State', 'Salt Lake CC'],
    nursingStats: {
      rnAdequacy: '79%',
      shortage: '4,100 RN shortage by 2030',
      jobGrowth: '18% growth through 2030',
      averageSalary: '$68,000'
    }
  },
  vermont: {
    name: 'Vermont',
    acceptanceRate: '65%',
    avgScore: 72.8,
    cutoffScore: '63',
    slug: 'vermont',
    colleges: ['UVM', 'Castleton', 'Norwich', 'Vermont Tech'],
    nursingStats: {
      rnAdequacy: '85%',
      shortage: '700 RN shortage by 2030',
      jobGrowth: '11% growth through 2030',
      averageSalary: '$71,000'
    }
  },
  virginia: {
    name: 'Virginia',
    acceptanceRate: '60%',
    avgScore: 74.4,
    cutoffScore: '65',
    slug: 'virginia',
    colleges: ['UVA', 'VCU', 'George Mason', 'James Madison', 'Old Dominion', 'NVCC'],
    nursingStats: {
      rnAdequacy: '82%',
      shortage: '9,800 RN shortage by 2030',
      jobGrowth: '14% growth through 2030',
      averageSalary: '$73,000'
    }
  },
  washington: {
    name: 'Washington',
    acceptanceRate: '55%',
    avgScore: 76.1,
    cutoffScore: '70',
    slug: 'washington',
    colleges: ['UW', 'WSU', 'Seattle U', 'Gonzaga', 'PLU', 'Bellevue College'],
    nursingStats: {
      rnAdequacy: '81%',
      shortage: '8,600 RN shortage by 2030',
      jobGrowth: '15% growth through 2030',
      averageSalary: '$95,000'
    }
  },
  'west-virginia': {
    name: 'West Virginia',
    acceptanceRate: '74%',
    avgScore: 70.6,
    cutoffScore: '60',
    slug: 'west-virginia',
    colleges: ['WVU', 'Marshall', 'Fairmont State', 'Shepherd Univ'],
    nursingStats: {
      rnAdequacy: '78%',
      shortage: '2,500 RN shortage by 2030',
      jobGrowth: '13% growth through 2030',
      averageSalary: '$62,000'
    }
  },
  wisconsin: {
    name: 'Wisconsin',
    acceptanceRate: '66%',
    avgScore: 73.2,
    cutoffScore: '64',
    slug: 'wisconsin',
    colleges: ['UW Madison', 'UW Milwaukee', 'Marquette', 'Bellin College', 'Madison College'],
    nursingStats: {
      rnAdequacy: '84%',
      shortage: '6,500 RN shortage by 2030',
      jobGrowth: '12% growth through 2030',
      averageSalary: '$70,000'
    }
  },
  wyoming: {
    name: 'Wyoming',
    acceptanceRate: '70%',
    avgScore: 71.9,
    cutoffScore: '62',
    slug: 'wyoming',
    colleges: ['UW Wyoming', 'Casper College', 'Laramie County CC'],
    nursingStats: {
      rnAdequacy: '81%',
      shortage: '600 RN shortage by 2030',
      jobGrowth: '14% growth through 2030',
      averageSalary: '$68,000'
    }
  },
};

// ========================================
// 2. DYNAMIC METADATA
// ========================================
export async function generateMetadata({ params }: { params: { state: string } }): Promise<Metadata> {
  const stateData = stateDatabase[params.state as keyof typeof stateDatabase];
  
  if (!stateData) {
    return { 
      title: 'State Not Found | StudyBuddy',
      description: 'The requested state page could not be found.'
    };
  }

  return {
    title: `Pass the TEAS 7 in ${stateData.name} (${stateData.avgScore}% Avg) | 100% Pass Guarantee | StudyBuddy`,
    description: `Ace the TEAS 7 for ${stateData.name} nursing programs. AI-powered prep with ${stateData.nursingStats.shortage}. Average score: ${stateData.avgScore}%. 100% Pass Guarantee. Start your free diagnostic now.`,
    openGraph: {
      title: `Pass the TEAS 7 in ${stateData.name} | StudyBuddy`,
      description: `AI-powered TEAS 7 prep tailored for ${stateData.name}. ${stateData.nursingStats.jobGrowth}. 100% Pass Guarantee.`,
      type: 'website',
      url: `https://studybuddy.live/states/${stateData.slug}`,
    },
    twitter: {
      card: 'summary_large_image',
      title: `Pass the TEAS 7 in ${stateData.name} | StudyBuddy`,
      description: `AI-powered TEAS 7 prep for ${stateData.name}. ${stateData.nursingStats.shortage}.`,
    },
    alternates: {
      canonical: `https://studybuddy.live/states/${stateData.slug}`,
    },
  };
}

export async function generateStaticParams() {
  return Object.keys(stateDatabase).map((state) => ({ state }));
}

// ========================================
// 3. MAIN PAGE COMPONENT
// ========================================
export default function StatePage({ params }: { params: { state: string } }) {
  const stateData = stateDatabase[params.state as keyof typeof stateDatabase];

  if (!stateData) {
    notFound();
  }

  // JSON-LD Structured Data
  const courseSchema = {
    "@context": "https://schema.org",
    "@type": "Course",
    "name": `TEAS 7 Prep Course for ${stateData.name}`,
    "description": `Comprehensive AI-powered TEAS 7 preparation course specifically designed for nursing students in ${stateData.name}. With ${stateData.nursingStats.shortage}, now is the time to prepare.`,
    "provider": {
      "@type": "Organization",
      "name": "StudyBuddy",
      "url": "https://studybuddy.live"
    },
    "offers": {
      "@type": "Offer",
      "price": "59.00",
      "priceCurrency": "USD",
      "availability": "https://schema.org/InStock",
      "url": `https://studybuddy.live/states/${stateData.slug}`
    },
    "hasCourseInstance": {
      "@type": "CourseInstance",
      "courseMode": "online",
      "courseWorkload": "PT12H"
    }
  };

  const faqSchema = {
    "@context": "https://schema.org",
    "@type": "FAQPage",
    "mainEntity": [
      {
        "@type": "Question",
        "name": "How does the Pass Guarantee work?",
        "acceptedAnswer": {
          "@type": "Answer",
          "text": "Complete the TEAS Pro course (1,000 questions + 80% completion) and if you don't pass, we refund you 100%. No questions asked."
        }
      },
      {
        "@type": "Question",
        "name": `What is a good TEAS 7 score for ${stateData.name}?`,
        "acceptedAnswer": {
          "@type": "Answer",
          "text": `While ${stateData.cutoffScore}% is passing, the average accepted student in ${stateData.name} has a ${stateData.avgScore}%. Our goal is to get you above that average.`
        }
      },
      {
        "@type": "Question",
        "name": `Is this specific to ${stateData.name} nursing programs?`,
        "acceptedAnswer": {
          "@type": "Answer",
          "text": `Yes. We aim for a score above ${stateData.cutoffScore}% to meet ${stateData.name} competitive standards. With ${stateData.nursingStats.shortage}, qualified nurses are in high demand.`
        }
      },
      {
        "@type": "Question",
        "name": "Are the practice exams realistic?",
        "acceptedAnswer": {
          "@type": "Answer",
          "text": "Yes. We use the exact same difficulty, format, and timing as the official ATI TEAS 7 exam."
        }
      }
    ]
  };

  return (
    <>
      {/* Facebook Pixel */}
      <Script id="facebook-pixel" strategy="afterInteractive">
        {`
          !function(f,b,e,v,n,t,s)
          {if(f.fbq)return;n=f.fbq=function(){n.callMethod?
          n.callMethod.apply(n,arguments):n.queue.push(arguments)};
          if(!f._fbq)f._fbq=n;n.push=n;n.loaded=!0;n.version='2.0';
          n.queue=[];t=b.createElement(e);t.async=!0;
          t.src=v;s=b.getElementsByTagName(e)[0];
          s.parentNode.insertBefore(t,s)}(window, document,'script',
          'https://connect.facebook.net/en_US/fbevents.js');
          fbq('init', '2253435838464992');
          fbq('track', 'PageView');
        `}
      </Script>
      <noscript>
        <img
          height="1"
          width="1"
          style={{ display: 'none' }}
          src="https://www.facebook.com/tr?id=2253435838464992&ev=PageView&noscript=1"
          alt=""
        />
      </noscript>

      {/* Google Tag Manager */}
      <Script id="google-tag-manager" strategy="afterInteractive">
        {`
          (function(w,d,s,l,i){w[l]=w[l]||[];w[l].push({'gtm.start':
          new Date().getTime(),event:'gtm.js'});var f=d.getElementsByTagName(s)[0],
          j=d.createElement(s),dl=l!='dataLayer'?'&l='+l:'';j.async=true;j.src=
          'https://www.googletagmanager.com/gtm.js?id='+i+dl;f.parentNode.insertBefore(j,f);
          })(window,document,'script','dataLayer','GTM-PJRBS3FP');
        `}
      </Script>
      <noscript>
        <iframe
          src="https://www.googletagmanager.com/ns.html?id=GTM-PJRBS3FP"
          height="0"
          width="0"
          style={{ display: 'none', visibility: 'hidden' }}
        />
      </noscript>

      {/* JSON-LD Structured Data */}
      <Script id="course-schema" type="application/ld+json" strategy="afterInteractive">
        {JSON.stringify(courseSchema)}
      </Script>
      <Script id="faq-schema" type="application/ld+json" strategy="afterInteractive">
        {JSON.stringify(faqSchema)}
      </Script>

      <div className="min-h-screen bg-white font-sans text-slate-900">
        
        {/* --- HERO SECTION --- */}
        <section className="relative bg-white pt-24 pb-12 px-4 sm:px-6 lg:px-8 overflow-hidden">
          <div className="max-w-7xl mx-auto">
            <div className="flex flex-col lg:flex-row items-center gap-12 lg:gap-20">
              
              {/* Left: Text Content */}
              <div className="flex-1 text-center lg:text-left z-10">
                <div className="inline-flex items-center gap-2 border border-slate-200 bg-white px-3 py-1 rounded-full text-[11px] font-bold tracking-wide mb-6 text-slate-500 uppercase shadow-sm">
                  <span className="w-2 h-2 rounded-full bg-green-500"></span>
                  2026 TEAS 7 EDITION
                </div>

                <h1 className="text-5xl lg:text-[4.5rem] font-extrabold text-slate-900 leading-[1.1] tracking-tight mb-6">
                  Pass the TEAS 7 in {stateData.name} <br className="hidden lg:block" />
                  <span className="text-[#2563EB]">Like It's Nothing.</span>
                </h1>

                <p className="text-xl text-slate-600 leading-relaxed mb-4 max-w-2xl mx-auto lg:mx-0">
                  With {stateData.nursingStats.shortage} and {stateData.nursingStats.jobGrowth}, {stateData.name} needs qualified nurses now more than ever.
                </p>
                
                <p className="text-lg text-slate-500 leading-relaxed mb-8 max-w-2xl mx-auto lg:mx-0">
                  The only AI-powered tutor that adapts to {stateData.name} nursing program requirements. Average RN adequacy: <span className="font-bold text-[#2563EB]">{stateData.nursingStats.rnAdequacy}</span>. Average salary: <span className="font-bold text-green-600">{stateData.nursingStats.averageSalary}</span>.
                </p>

                <div className="flex flex-col sm:flex-row gap-4 justify-center lg:justify-start mb-12">
                  <Link 
                    href={`/diagnostic?state=${stateData.slug}`}
                    className="bg-[#2563EB] text-white px-8 py-4 rounded-xl font-bold text-lg hover:bg-blue-700 transition-all shadow-xl hover:shadow-2xl transform hover:-translate-y-1 inline-flex justify-center items-center"
                  >
                    Get My Free Study Plan <span className="ml-2">→</span>
                  </Link>
                </div>
              </div>

              {/* Right: Video */}
              <div className="flex-1 w-full max-w-[650px] relative z-10">
                <div className="relative rounded-2xl overflow-hidden shadow-2xl bg-slate-900 aspect-video ring-1 ring-slate-900/10 border-4 border-white">
                  <video
                    autoPlay
                    muted
                    loop
                    playsInline
                    className="w-full h-full object-cover"
                  >
                    <source src="/ai-tutor.mp4" type="video/mp4" />
                  </video>
                  
                  {/* AI Status Badge */}
                  <div className="absolute top-6 left-6 bg-white px-4 py-2 rounded-lg shadow-md flex items-center gap-3">
                      <div className="text-blue-600">
                        <svg width="24" height="24" viewBox="0 0 24 24" fill="none" stroke="currentColor" strokeWidth="2"><path d="M12 2L2 7l10 5 10-5-10-5zM2 17l10 5 10-5M2 12l10 5 10-5"/></svg>
                      </div>
                      <div>
                        <div className="text-[10px] font-bold text-slate-400 uppercase tracking-wider">AI Tutor Status</div>
                        <div className="text-sm font-bold text-[#1e3a8a]">Online & Ready</div>
                      </div>
                  </div>
                </div>
                
                <div className="absolute -top-10 -right-10 w-64 h-64 bg-blue-200 rounded-full opacity-30 blur-3xl -z-10" />
                <div className="absolute -bottom-10 -left-10 w-64 h-64 bg-pink-200 rounded-full opacity-30 blur-3xl -z-10" />
              </div>
            </div>
          </div>
        </section>

        {/* --- TRUST BAR --- */}
        <section className="bg-white py-12 border-t border-slate-100">
          <div className="max-w-7xl mx-auto px-4 text-center">
            <p className="text-[10px] font-bold text-slate-400 tracking-[0.15em] uppercase mb-8">
              PREFERRED BY PHI THETA KAPPA MEMBERS & STUDENTS ASPIRING TO ATTEND NURSING PROGRAMS IN {stateData.name.toUpperCase()}
            </p>
            
            <div className="flex flex-wrap justify-center items-center gap-x-12 gap-y-8 opacity-70">
               <span className="text-2xl font-serif font-bold text-slate-700">Phi Theta Kappa</span>
               {stateData.colleges.map((college, i) => (
                  <span key={i} className="text-xl font-bold text-slate-500 hover:text-slate-800 transition-colors">
                     {college}
                  </span>
               ))}
            </div>
          </div>
        </section>

        {/* --- URGENCY SECTION (NEW) --- */}
        <section className="py-16 px-4 bg-gradient-to-br from-blue-50 to-indigo-50 border-y border-blue-100">
          <div className="max-w-7xl mx-auto">
            <div className="text-center mb-12">
              <h2 className="text-3xl font-extrabold text-slate-900 mb-4">
                {stateData.name} Nursing Shortage Crisis
              </h2>
              <p className="text-lg text-slate-600">
                The demand for qualified nurses in {stateData.name} has never been higher.
              </p>
            </div>
            
            <div className="grid md:grid-cols-4 gap-6">
              <div className="bg-white rounded-xl p-6 shadow-sm border border-blue-100 text-center">
                <div className="text-4xl font-extrabold text-red-600 mb-2">{stateData.nursingStats.rnAdequacy}</div>
                <div className="text-sm font-medium text-slate-600">Current RN Adequacy</div>
              </div>
              <div className="bg-white rounded-xl p-6 shadow-sm border border-blue-100 text-center">
                <div className="text-2xl font-extrabold text-orange-600 mb-2">{stateData.nursingStats.shortage.split(' ')[0]}</div>
                <div className="text-sm font-medium text-slate-600">Projected Shortage by 2030</div>
              </div>
              <div className="bg-white rounded-xl p-6 shadow-sm border border-blue-100 text-center">
                <div className="text-4xl font-extrabold text-green-600 mb-2">{stateData.nursingStats.jobGrowth.split(' ')[0]}</div>
                <div className="text-sm font-medium text-slate-600">Job Growth Rate</div>
              </div>
              <div className="bg-white rounded-xl p-6 shadow-sm border border-blue-100 text-center">
                <div className="text-3xl font-extrabold text-blue-600 mb-2">{stateData.nursingStats.averageSalary}</div>
                <div className="text-sm font-medium text-slate-600">Average RN Salary</div>
              </div>
            </div>
          </div>
        </section>

        {/* --- HOW IT WORKS --- */}
        <section className="py-24 px-4 bg-[#F8FAFC]">
          <div className="max-w-7xl mx-auto">
            <div className="text-center mb-20">
              <h2 className="text-4xl font-extrabold text-slate-900 mb-6">Why Generic Prep Fails in {stateData.name}</h2>
              <p className="text-xl text-slate-600 max-w-2xl mx-auto">
                 The average TEAS score in {stateData.name} is {stateData.avgScore}%. You need to score above {stateData.cutoffScore}% minimum to be competitive.
              </p>
            </div>

            <div className="grid md:grid-cols-3 gap-12">
              <div className="flex flex-col items-start p-6 bg-white rounded-2xl shadow-sm border border-slate-100">
                  <div className="w-12 h-12 bg-blue-50 rounded-lg flex items-center justify-center mb-6 text-[#2563EB]">
                    <svg width="24" height="24" fill="none" viewBox="0 0 24 24" stroke="currentColor" strokeWidth="2"><path d="M9 12h6m-6 4h6m2 5H7a2 2 0 01-2-2V5a2 2 0 012-2h5.586a1 1 0 01.707.293l5.414 5.414a1 1 0 01.293.707V19a2 2 0 01-2 2z" /></svg>
                  </div>
                  <h3 className="text-xl font-bold text-slate-900 mb-3">1. AI Diagnosis</h3>
                  <p className="text-slate-600">We analyze your weak spots specifically against {stateData.name} nursing requirements.</p>
              </div>
              
              <div className="flex flex-col items-start p-6 bg-white rounded-2xl shadow-sm border border-slate-100">
                  <div className="w-12 h-12 bg-amber-50 rounded-lg flex items-center justify-center mb-6 text-amber-500">
                    <svg width="24" height="24" fill="none" viewBox="0 0 24 24" stroke="currentColor" strokeWidth="2"><path d="M9 12l2 2 4-4m6 2a9 9 0 11-18 0 9 9 0 0118 0z" /></svg>
                  </div>
                  <h3 className="text-xl font-bold text-slate-900 mb-3">2. Targeted Study</h3>
                  <p className="text-slate-600">Focus only on what you don't know. Don't waste time on easy topics.</p>
              </div>
              
              <div className="flex flex-col items-start p-6 bg-white rounded-2xl shadow-sm border border-slate-100">
                  <div className="w-12 h-12 bg-green-50 rounded-lg flex items-center justify-center mb-6 text-green-600">
                    <svg width="24" height="24" fill="none" viewBox="0 0 24 24" stroke="currentColor" strokeWidth="2"><path d="M12 15v2m-6 4h12a2 2 0 002-2v-6a2 2 0 00-2-2H6a2 2 0 00-2 2v6a2 2 0 002 2zm10-10V7a4 4 0 00-8 0v4h8z" /></svg>
                  </div>
                  <h3 className="text-xl font-bold text-slate-900 mb-3">3. Pass Guaranteed</h3>
                  <p className="text-slate-600">Score above {stateData.cutoffScore}% or get your money back. No questions asked.</p>
              </div>
            </div>
          </div>
        </section>

        {/* --- PRICING SECTION --- */}
        <section id="pricing" className="py-24 px-4 bg-white">
          <div className="max-w-7xl mx-auto">
            <div className="text-center mb-16">
              <h2 className="text-4xl font-bold text-slate-900 mb-4">Simple Pricing for {stateData.name} Students</h2>
              <p className="text-xl text-slate-600 max-w-2xl mx-auto">Join the {stateData.nursingStats.jobGrowth} opportunity. Start with confidence.</p>
            </div>

            <div className="grid md:grid-cols-2 gap-8 max-w-4xl mx-auto items-start">
              
              {/* 1. MONTHLY PLAN */}
              <div className="bg-white rounded-3xl p-8 border border-slate-200 hover:shadow-lg transition-all h-full flex flex-col">
                <div className="mb-4">
                  <span className="text-xs font-bold text-slate-500 uppercase tracking-wider">Flexible Start</span>
                  <h3 className="text-3xl font-bold text-slate-900 mt-2">Monthly Plan</h3>
                </div>
                <div className="mb-6">
                  <div className="flex items-baseline">
                    <span className="text-5xl font-extrabold text-slate-900">$24.99</span>
                    <span className="text-slate-500 font-medium ml-1">/mo</span>
                  </div>
                  <p className="text-slate-400 text-sm mt-2">Cancel anytime.</p>
                </div>
                
                <ul className="space-y-4 mb-8 flex-1 mt-6">
                  <li className="flex gap-3 text-slate-700 items-center"><svg className="w-5 h-5 text-[#2563EB]" viewBox="0 0 20 20" fill="currentColor"><path fillRule="evenodd" d="M16.707 5.293a1 1 0 010 1.414l-8 8a1 1 0 01-1.414 0l-4-4a1 1 0 011.414-1.414L8 12.586l7.293-7.293a1 1 0 011.414 0z" clipRule="evenodd"/></svg> Full TEAS 7 Course</li>
                  <li className="flex gap-3 text-slate-700 items-center"><svg className="w-5 h-5 text-[#2563EB]" viewBox="0 0 20 20" fill="currentColor"><path fillRule="evenodd" d="M16.707 5.293a1 1 0 010 1.414l-8 8a1 1 0 01-1.414 0l-4-4a1 1 0 011.414-1.414L8 12.586l7.293-7.293a1 1 0 011.414 0z" clipRule="evenodd"/></svg> 4,000+ Practice Questions</li>
                  <li className="flex gap-3 text-slate-700 items-center"><svg className="w-5 h-5 text-[#2563EB]" viewBox="0 0 20 20" fill="currentColor"><path fillRule="evenodd" d="M16.707 5.293a1 1 0 010 1.414l-8 8a1 1 0 01-1.414 0l-4-4a1 1 0 011.414-1.414L8 12.586l7.293-7.293a1 1 0 011.414 0z" clipRule="evenodd"/></svg> Mobile App Access</li>
                  <li className="flex gap-3 text-slate-400 items-center"><span className="text-slate-300">✕</span> Limited AI Tutor</li>
                  <li className="flex gap-3 text-slate-400 items-center"><span className="text-slate-300">✕</span> No Pass Guarantee</li>
                </ul>
                
                {/* ✅ UPDATED MONTHLY LINK */}
                <Link href="https://learn.studybuddy.live/subscription/2499" className="block w-full text-center border-2 border-slate-200 text-slate-700 py-4 rounded-xl font-bold hover:border-slate-300 hover:bg-slate-50 transition-all text-lg">
                  Start Monthly Plan
                </Link>
              </div>

              {/* 2. TEAS PASSER PRO */}
              <div className="bg-white rounded-3xl p-8 border-2 border-[#2563EB] shadow-2xl relative h-full flex flex-col transform md:-translate-y-4 z-10">
                
                {/* ORANGE BADGE */}
                <div className="absolute -top-5 left-1/2 transform -translate-x-1/2">
                  <div className="bg-[#F59E0B] text-white px-6 py-1.5 rounded-full font-bold text-xs shadow-lg tracking-wide uppercase flex items-center gap-1">
                    <span className="text-white">✨</span> MOST POPULAR
                  </div>
                </div>

                <div className="mb-2 mt-2">
                  <span className="text-xs font-bold text-[#2563EB] uppercase tracking-wider">Total Protection</span>
                  <h3 className="text-3xl font-bold text-slate-900 mt-2">TEAS Passer Pro</h3>
                </div>
                
                <div className="mb-6">
                  <div className="flex items-baseline">
                    <span className="text-6xl font-extrabold text-slate-900">$59</span>
                    <span className="text-slate-500 font-medium ml-2 text-xl">/ 3 months</span>
                  </div>
                  {/* Green Pill */}
                  <div className="mt-3 inline-block bg-[#DCFCE7] text-[#166534] text-sm font-bold px-3 py-1 rounded-md">
                    Save $16 vs. Monthly
                  </div>
                </div>

                <ul className="space-y-4 mb-8 flex-1 mt-4">
                  <li className="flex gap-3 text-slate-900 font-medium items-center"><svg className="w-5 h-5 text-[#2563EB]" viewBox="0 0 20 20" fill="currentColor"><path fillRule="evenodd" d="M16.707 5.293a1 1 0 010 1.414l-8 8a1 1 0 01-1.414 0l-4-4a1 1 0 011.414-1.414L8 12.586l7.293-7.293a1 1 0 011.414 0z" clipRule="evenodd"/></svg> Everything in Core Course</li>
                  
                  {/* AI Tutor Box - Blue */}
                  <li className="bg-[#EFF6FF] p-4 rounded-xl border border-blue-100 flex gap-3 items-start">
                      <div className="text-[#2563EB] mt-1"><svg width="20" height="20" fill="none" stroke="currentColor" strokeWidth="2" viewBox="0 0 24 24"><path d="M13 10V3L4 14h7v7l9-11h-7z"/></svg></div>
                      <div>
                        <div className="font-bold text-[#1e3a8a] text-sm">UNLIMITED AI Tutor (Gold Status)</div>
                        <div className="text-xs text-[#3b82f6]">No daily limits. Ask anything.</div>
                      </div>
                  </li>

                  {/* Guarantee Box - Green */}
                  <li className="bg-[#F0FDF4] p-4 rounded-xl border border-green-100 flex gap-3 items-start">
                      <div className="text-green-600 mt-1"><svg width="20" height="20" fill="none" stroke="currentColor" strokeWidth="2" viewBox="0 0 24 24"><path d="M9 12l2 2 4-4m5.618-4.016A11.955 11.955 0 0112 2.944a11.955 11.955 0 01-8.618 3.04A12.02 12.02 0 003 9c0 5.591 3.824 10.29 9 11.622 5.176-1.332 9-6.03 9-11.622 0-1.042-.133-2.052-.382-3.016z"/></svg></div>
                      <div>
                        <div className="font-bold text-green-800 text-sm">100% Pass Guarantee*</div>
                        <div className="text-xs text-green-600">Pass or get a full refund.</div>
                      </div>
                  </li>

                  <li className="flex gap-3 text-slate-900 font-medium items-center"><svg className="w-5 h-5 text-[#2563EB]" viewBox="0 0 20 20" fill="currentColor"><path fillRule="evenodd" d="M16.707 5.293a1 1 0 010 1.414l-8 8a1 1 0 01-1.414 0l-4-4a1 1 0 011.414-1.414L8 12.586l7.293-7.293a1 1 0 011.414 0z" clipRule="evenodd"/></svg> Priority VIP Support</li>
                  <li className="flex gap-3 text-slate-900 font-medium items-center"><svg className="w-5 h-5 text-[#2563EB]" viewBox="0 0 20 20" fill="currentColor"><path fillRule="evenodd" d="M16.707 5.293a1 1 0 010 1.414l-8 8a1 1 0 01-1.414 0l-4-4a1 1 0 011.414-1.414L8 12.586l7.293-7.293a1 1 0 011.414 0z" clipRule="evenodd"/></svg> One-time payment (No recurring)</li>
                </ul>

                {/* ✅ UPDATED PRO LINK */}
                <Link href="https://learn.studybuddy.live/subscription/59-3-months" className="block w-full text-center bg-[#2563EB] text-white py-4 rounded-xl font-bold hover:bg-blue-700 shadow-lg hover:shadow-blue-500/30 transition-all text-lg">
                  Get 3-Month Access
                </Link>
                
                <p className="text-[10px] text-slate-400 text-center mt-4">
                  *Terms apply. Requires 90% course completion & official score report.
                </p>
              </div>
            </div>
          </div>
        </section>

        {/* --- FAQ SECTION --- */}
        <section className="py-24 px-4 bg-[#F8FAFC]">
          <div className="max-w-3xl mx-auto">
            <div className="text-center mb-16">
              <h2 className="text-4xl font-bold text-slate-900 mb-4">Frequently Asked Questions</h2>
              <p className="text-slate-600">Everything you need to know about the TEAS 7 in {stateData.name}.</p>
            </div>
            
            <div className="space-y-4">
              <details className="group border border-slate-200 rounded-2xl p-6 bg-white open:ring-1 open:ring-blue-100">
                <summary className="flex items-center justify-between cursor-pointer list-none font-bold text-slate-900">
                  How does the Pass Guarantee work?
                  <span className="text-slate-400 group-open:rotate-180 transition-transform">▼</span>
                </summary>
                <div className="mt-4 text-slate-600 leading-relaxed">
                  Complete the TEAS Pro course (1,000 questions + 80% completion) and if you don't pass, we refund you 100%. No questions asked.
                </div>
              </details>

              <details className="group border border-slate-200 rounded-2xl p-6 bg-white open:ring-1 open:ring-blue-100">
                <summary className="flex items-center justify-between cursor-pointer list-none font-bold text-slate-900">
                  Are the practice exams realistic?
                  <span className="text-slate-400 group-open:rotate-180 transition-transform">▼</span>
                </summary>
                <div className="mt-4 text-slate-600 leading-relaxed">
                  Yes. We use the exact same difficulty, format, and timing as the official ATI TEAS 7 exam.
                </div>
              </details>

              <details className="group border border-slate-200 rounded-2xl p-6 bg-white open:ring-1 open:ring-blue-100">
                <summary className="flex items-center justify-between cursor-pointer list-none font-bold text-slate-900">
                  What specific subjects are on the TEAS 7?
                  <span className="text-slate-400 group-open:rotate-180 transition-transform">▼</span>
                </summary>
                <div className="mt-4 text-slate-600 leading-relaxed">
                  Reading (Key Ideas, Craft & Structure), Math (Numbers, Algebra, Measurement), Science (A&P, Biology, Chemistry), and English (Convention, Grammar, Vocabulary).
                </div>
              </details>

              <details className="group border border-slate-200 rounded-2xl p-6 bg-white open:ring-1 open:ring-blue-100">
                <summary className="flex items-center justify-between cursor-pointer list-none font-bold text-slate-900">
                  Can I use a calculator on the TEAS 7?
                  <span className="text-slate-400 group-open:rotate-180 transition-transform">▼</span>
                </summary>
                <div className="mt-4 text-slate-600 leading-relaxed">
                  Yes, a four-function calculator is allowed and embedded in our practice tests, just like the real exam.
                </div>
              </details>

              <details className="group border border-slate-200 rounded-2xl p-6 bg-white open:ring-1 open:ring-blue-100">
                <summary className="flex items-center justify-between cursor-pointer list-none font-bold text-slate-900">
                  Does StudyBuddy work on my phone or tablet?
                  <span className="text-slate-400 group-open:rotate-180 transition-transform">▼</span>
                </summary>
                <div className="mt-4 text-slate-600 leading-relaxed">
                  Yes! The platform is fully mobile-optimized so you can study on the go.
                </div>
              </details>

              <details className="group border border-slate-200 rounded-2xl p-6 bg-white open:ring-1 open:ring-blue-100">
                <summary className="flex items-center justify-between cursor-pointer list-none font-bold text-slate-900">
                  Is this course updated for the 2026 TEAS 7?
                  <span className="text-slate-400 group-open:rotate-180 transition-transform">▼</span>
                </summary>
                <div className="mt-4 text-slate-600 leading-relaxed">
                  Yes. We update our question bank weekly to match the latest ATI standards for 2025-2026.
                </div>
              </details>

              <details className="group border border-slate-200 rounded-2xl p-6 bg-blue-50/50 open:ring-1 open:ring-blue-200">
                <summary className="flex items-center justify-between cursor-pointer list-none font-bold text-slate-900">
                  Is this specific to {stateData.name} nursing programs?
                  <span className="text-slate-400 group-open:rotate-180 transition-transform">▼</span>
                </summary>
                <div className="mt-4 text-slate-600 leading-relaxed">
                  Yes. We aim for a score above {stateData.cutoffScore}% to meet {stateData.name} competitive standards. With {stateData.nursingStats.shortage}, qualified nurses are in high demand.
                </div>
              </details>

              <details className="group border border-slate-200 rounded-2xl p-6 bg-blue-50/50 open:ring-1 open:ring-blue-200">
                <summary className="flex items-center justify-between cursor-pointer list-none font-bold text-slate-900">
                  What is a good TEAS 7 score for {stateData.name}?
                  <span className="text-slate-400 group-open:rotate-180 transition-transform">▼</span>
                </summary>
                <div className="mt-4 text-slate-600 leading-relaxed">
                  While {stateData.cutoffScore}% is passing, the average accepted student in {stateData.name} has a {stateData.avgScore}%. Our goal is to get you above that average to capitalize on the {stateData.nursingStats.jobGrowth}.
                </div>
              </details>
            </div>
          </div>
        </section>

        {/* --- FINAL CTA --- */}
        <section className="bg-white py-20 px-4 sm:px-6 lg:px-8 text-center border-t border-slate-100">
          <h2 className="text-4xl md:text-5xl font-bold text-slate-900 mb-6">Ready to Pass in {stateData.name}?</h2>
          <p className="text-lg text-slate-600 mb-8 max-w-2xl mx-auto">
            Join the {stateData.nursingStats.jobGrowth} and earn an average of {stateData.nursingStats.averageSalary} as an RN.
          </p>
          <Link 
            href={`/diagnostic?state=${stateData.slug}`}
            className="bg-[#2563EB] text-white px-10 py-5 rounded-xl font-bold text-xl hover:bg-blue-700 transition-all shadow-xl inline-block"
          >
            Start Free Diagnostic
          </Link>
          <p className="text-slate-400 mt-6 font-medium text-sm">No credit card required • 2-minute setup</p>
        </section>

        {/* --- AI CHAT WIDGET --- */}
        <AIChat />

      </div>
    </>
  );
}