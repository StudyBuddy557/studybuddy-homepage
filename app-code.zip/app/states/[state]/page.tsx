'use client';

import Link from 'next/link';
import { useParams } from 'next/navigation';
import { Check, BookOpen, Target, TrendingUp, Users, MapPin, GraduationCap } from 'lucide-react';

// State-specific data mapping
const STATE_DATA: Record<string, {
  name: string;
  schools: string[];
  avgScore: string;
  programs: number;
}> = {
  'alabama': {
    name: 'Alabama',
    schools: ['University of Alabama', 'Auburn University', 'UAB School of Nursing', 'Troy University', 'University of South Alabama'],
    avgScore: '65-70',
    programs: 45
  },
  'alaska': {
    name: 'Alaska',
    schools: ['University of Alaska Anchorage', 'Alaska Pacific University'],
    avgScore: '62-68',
    programs: 8
  },
  'arizona': {
    name: 'Arizona',
    schools: ['Arizona State University', 'University of Arizona', 'Northern Arizona University', 'Grand Canyon University', 'Chamberlain University'],
    avgScore: '65-72',
    programs: 38
  },
  'arkansas': {
    name: 'Arkansas',
    schools: ['University of Arkansas', 'Arkansas State University', 'University of Central Arkansas', 'Harding University'],
    avgScore: '63-69',
    programs: 32
  },
  'california': {
    name: 'California',
    schools: ['UCLA', 'UC San Francisco', 'Stanford University', 'USC', 'San Diego State University', 'CSU Sacramento', 'Samuel Merritt University'],
    avgScore: '68-75',
    programs: 156
  },
  'colorado': {
    name: 'Colorado',
    schools: ['University of Colorado', 'Regis University', 'Colorado Mesa University', 'Metropolitan State University'],
    avgScore: '66-72',
    programs: 34
  },
  'connecticut': {
    name: 'Connecticut',
    schools: ['Yale School of Nursing', 'University of Connecticut', 'Sacred Heart University', 'Quinnipiac University'],
    avgScore: '67-73',
    programs: 28
  },
  'delaware': {
    name: 'Delaware',
    schools: ['University of Delaware', 'Wilmington University', 'Delaware State University'],
    avgScore: '64-70',
    programs: 12
  },
  'florida': {
    name: 'Florida',
    schools: ['University of Florida', 'Florida State University', 'University of Miami', 'University of Central Florida', 'Florida Atlantic University', 'University of South Florida'],
    avgScore: '65-71',
    programs: 98
  },
  'georgia': {
    name: 'Georgia',
    schools: ['Emory University', 'Georgia State University', 'Medical College of Georgia', 'Kennesaw State University', 'Georgia Southern University'],
    avgScore: '66-72',
    programs: 67
  },
  'hawaii': {
    name: 'Hawaii',
    schools: ['University of Hawaii at Manoa', 'Hawaii Pacific University', 'Chaminade University'],
    avgScore: '63-69',
    programs: 14
  },
  'idaho': {
    name: 'Idaho',
    schools: ['Boise State University', 'Idaho State University', 'Northwest Nazarene University'],
    avgScore: '62-68',
    programs: 16
  },
  'illinois': {
    name: 'Illinois',
    schools: ['Northwestern University', 'University of Illinois Chicago', 'Rush University', 'Loyola University', 'Illinois State University'],
    avgScore: '67-73',
    programs: 89
  },
  'indiana': {
    name: 'Indiana',
    schools: ['Indiana University', 'Purdue University', 'Ball State University', 'Valparaiso University', 'University of Indianapolis'],
    avgScore: '65-71',
    programs: 54
  },
  'iowa': {
    name: 'Iowa',
    schools: ['University of Iowa', 'Iowa State University', 'Allen College', 'Mercy College'],
    avgScore: '64-70',
    programs: 28
  },
  'kansas': {
    name: 'Kansas',
    schools: ['University of Kansas', 'Kansas State University', 'Wichita State University', 'Washburn University'],
    avgScore: '63-69',
    programs: 32
  },
  'kentucky': {
    name: 'Kentucky',
    schools: ['University of Kentucky', 'University of Louisville', 'Bellarmine University', 'Eastern Kentucky University'],
    avgScore: '64-70',
    programs: 38
  },
  'louisiana': {
    name: 'Louisiana',
    schools: ['LSU Health Sciences Center', 'Tulane University', 'University of Louisiana Lafayette', 'Southeastern Louisiana University'],
    avgScore: '63-69',
    programs: 42
  },
  'maine': {
    name: 'Maine',
    schools: ['University of Maine', 'University of Southern Maine', 'Husson University', 'Saint Joseph\'s College'],
    avgScore: '62-68',
    programs: 18
  },
  'maryland': {
    name: 'Maryland',
    schools: ['Johns Hopkins University', 'University of Maryland', 'Towson University', 'Salisbury University', 'Coppin State University'],
    avgScore: '67-73',
    programs: 46
  },
  'massachusetts': {
    name: 'Massachusetts',
    schools: ['Boston College', 'Northeastern University', 'University of Massachusetts', 'Simmons University', 'MGH Institute of Health Professions'],
    avgScore: '68-74',
    programs: 64
  },
  'michigan': {
    name: 'Michigan',
    schools: ['University of Michigan', 'Michigan State University', 'Wayne State University', 'Oakland University', 'Grand Valley State University'],
    avgScore: '66-72',
    programs: 72
  },
  'minnesota': {
    name: 'Minnesota',
    schools: ['University of Minnesota', 'Mayo Clinic School of Nursing', 'St. Catherine University', 'Metropolitan State University', 'Bethel University'],
    avgScore: '66-72',
    programs: 48
  },
  'mississippi': {
    name: 'Mississippi',
    schools: ['University of Mississippi', 'Mississippi State University', 'University of Southern Mississippi', 'Alcorn State University'],
    avgScore: '62-68',
    programs: 34
  },
  'missouri': {
    name: 'Missouri',
    schools: ['University of Missouri', 'Washington University', 'Saint Louis University', 'Missouri State University', 'University of Central Missouri'],
    avgScore: '65-71',
    programs: 56
  },
  'montana': {
    name: 'Montana',
    schools: ['Montana State University', 'University of Montana', 'Carroll College', 'Salish Kootenai College'],
    avgScore: '62-68',
    programs: 12
  },
  'nebraska': {
    name: 'Nebraska',
    schools: ['University of Nebraska Medical Center', 'Creighton University', 'Nebraska Methodist College', 'Nebraska Wesleyan University'],
    avgScore: '64-70',
    programs: 24
  },
  'nevada': {
    name: 'Nevada',
    schools: ['University of Nevada Las Vegas', 'University of Nevada Reno', 'Nevada State College', 'Touro University'],
    avgScore: '63-69',
    programs: 18
  },
  'new-hampshire': {
    name: 'New Hampshire',
    schools: ['University of New Hampshire', 'Southern New Hampshire University', 'Rivier University', 'Saint Anselm College'],
    avgScore: '64-70',
    programs: 16
  },
  'new-jersey': {
    name: 'New Jersey',
    schools: ['Rutgers University', 'Seton Hall University', 'The College of New Jersey', 'Fairleigh Dickinson University', 'Monmouth University'],
    avgScore: '66-72',
    programs: 52
  },
  'new-mexico': {
    name: 'New Mexico',
    schools: ['University of New Mexico', 'New Mexico State University', 'Eastern New Mexico University', 'Western New Mexico University'],
    avgScore: '62-68',
    programs: 22
  },
  'new-york': {
    name: 'New York',
    schools: ['NYU Rory Meyers College', 'Columbia University', 'SUNY Buffalo', 'University of Rochester', 'Stony Brook University', 'CUNY Hunter College'],
    avgScore: '68-74',
    programs: 124
  },
  'north-carolina': {
    name: 'North Carolina',
    schools: ['UNC Chapel Hill', 'Duke University', 'East Carolina University', 'UNC Charlotte', 'UNC Greensboro', 'Winston-Salem State University'],
    avgScore: '66-72',
    programs: 78
  },
  'north-dakota': {
    name: 'North Dakota',
    schools: ['University of North Dakota', 'North Dakota State University', 'Minot State University', 'Dickinson State University'],
    avgScore: '62-68',
    programs: 14
  },
  'ohio': {
    name: 'Ohio',
    schools: ['Ohio State University', 'Case Western Reserve University', 'University of Cincinnati', 'Cleveland State University', 'Kent State University', 'Ohio University'],
    avgScore: '66-72',
    programs: 86
  },
  'oklahoma': {
    name: 'Oklahoma',
    schools: ['University of Oklahoma', 'Oklahoma State University', 'University of Central Oklahoma', 'Northeastern State University'],
    avgScore: '63-69',
    programs: 36
  },
  'oregon': {
    name: 'Oregon',
    schools: ['Oregon Health & Science University', 'University of Portland', 'Linfield University', 'Oregon Institute of Technology'],
    avgScore: '65-71',
    programs: 28
  },
  'pennsylvania': {
    name: 'Pennsylvania',
    schools: ['University of Pennsylvania', 'University of Pittsburgh', 'Penn State University', 'Drexel University', 'Villanova University', 'Thomas Jefferson University'],
    avgScore: '67-73',
    programs: 94
  },
  'rhode-island': {
    name: 'Rhode Island',
    schools: ['University of Rhode Island', 'Rhode Island College', 'Salve Regina University'],
    avgScore: '64-70',
    programs: 14
  },
  'south-carolina': {
    name: 'South Carolina',
    schools: ['University of South Carolina', 'Medical University of South Carolina', 'Clemson University', 'Charleston Southern University'],
    avgScore: '65-71',
    programs: 38
  },
  'south-dakota': {
    name: 'South Dakota',
    schools: ['South Dakota State University', 'University of South Dakota', 'Mount Marty University', 'Augustana University'],
    avgScore: '62-68',
    programs: 12
  },
  'tennessee': {
    name: 'Tennessee',
    schools: ['Vanderbilt University', 'University of Tennessee Knoxville', 'University of Memphis', 'Belmont University', 'Middle Tennessee State University'],
    avgScore: '66-72',
    programs: 54
  },
  'texas': {
    name: 'Texas',
    schools: ['UT Austin', 'Texas A&M', 'UT Arlington', 'Texas Tech', 'UT Health San Antonio', 'Baylor University', 'Texas Woman\'s University'],
    avgScore: '67-73',
    programs: 134
  },
  'utah': {
    name: 'Utah',
    schools: ['University of Utah', 'Brigham Young University', 'Weber State University', 'Utah Valley University', 'Westminster College'],
    avgScore: '65-71',
    programs: 24
  },
  'vermont': {
    name: 'Vermont',
    schools: ['University of Vermont', 'Norwich University', 'Vermont State University'],
    avgScore: '63-69',
    programs: 10
  },
  'virginia': {
    name: 'Virginia',
    schools: ['University of Virginia', 'Virginia Commonwealth University', 'Old Dominion University', 'George Mason University', 'James Madison University'],
    avgScore: '66-72',
    programs: 58
  },
  'washington': {
    name: 'Washington',
    schools: ['University of Washington', 'Seattle University', 'Washington State University', 'Pacific Lutheran University', 'Seattle Pacific University'],
    avgScore: '66-72',
    programs: 44
  },
  'west-virginia': {
    name: 'West Virginia',
    schools: ['West Virginia University', 'Marshall University', 'Shepherd University', 'West Virginia Wesleyan College'],
    avgScore: '62-68',
    programs: 22
  },
  'wisconsin': {
    name: 'Wisconsin',
    schools: ['University of Wisconsin Madison', 'Marquette University', 'UW Milwaukee', 'Concordia University', 'Carroll University'],
    avgScore: '65-71',
    programs: 48
  },
  'wyoming': {
    name: 'Wyoming',
    schools: ['University of Wyoming', 'Casper College'],
    avgScore: '61-67',
    programs: 6
  }
};

export default function StatePage() {
  const params = useParams();
  const stateSlug = params?.state as string;
  const stateData = STATE_DATA[stateSlug];

  if (!stateData) {
    return (
      <div className="min-h-screen flex items-center justify-center bg-slate-50">
        <div className="text-center">
          <h1 className="text-3xl font-bold text-slate-900 mb-4">State Not Found</h1>
          <Link href="/" className="text-[#20B2AA] hover:underline">
            Return to Homepage
          </Link>
        </div>
      </div>
    );
  }

  return (
    <main className="min-h-screen bg-white font-sans text-[#1A1A1A]">
      {/* Hero Section */}
      <section className="relative overflow-hidden pt-32 pb-20 bg-gradient-to-b from-slate-50 to-white">
        <div className="mx-auto max-w-7xl px-4 sm:px-6 lg:px-8">
          <div className="text-center mb-16">
            <div className="inline-flex items-center gap-2 rounded-full border border-[#20B2AA]/20 bg-[#20B2AA]/5 px-4 py-1.5 backdrop-blur-sm shadow-sm mb-6">
              <MapPin className="w-4 h-4 text-[#20B2AA]" />
              <span className="text-xs font-bold tracking-widest text-[#1E3A8A] uppercase">{stateData.name}</span>
            </div>

            <h1 className="text-4xl sm:text-5xl lg:text-6xl font-extrabold tracking-tight text-[#1A1A1A] leading-tight mb-6">
              TEAS 7 Requirements for<br />
              <span className="bg-gradient-to-r from-[#20B2AA] to-[#1E3A8A] bg-clip-text text-transparent">
                {stateData.name} Nursing Programs
              </span>
            </h1>

            <p className="text-xl text-slate-600 mb-10 max-w-3xl mx-auto">
              Complete guide to TEAS 7 score requirements, program details, and everything you need to know for {stateData.name} nursing schools.
            </p>

            <div className="flex flex-col sm:flex-row gap-4 justify-center">
              <Link
                href="/diagnostic"
                className="inline-flex items-center justify-center px-8 py-4 rounded-2xl bg-[#20B2AA] text-white font-bold shadow-lg hover:bg-[#18968F] hover:scale-105 transition-all"
              >
                Take Free Diagnostic →
              </Link>
              <Link
                href="/#pricing"
                className="inline-flex items-center justify-center px-8 py-4 rounded-2xl bg-white border-2 border-slate-200 text-slate-700 font-bold hover:border-[#20B2AA] transition-all"
              >
                View Pricing
              </Link>
            </div>
          </div>

          {/* Quick Stats */}
          <div className="grid sm:grid-cols-3 gap-6 max-w-4xl mx-auto">
            <div className="bg-white rounded-2xl border border-slate-200 p-6 shadow-sm">
              <div className="flex items-center gap-3 mb-2">
                <GraduationCap className="w-6 h-6 text-[#20B2AA]" />
                <h3 className="font-bold text-2xl text-[#1A1A1A]">{stateData.programs}+</h3>
              </div>
              <p className="text-sm text-slate-600">Nursing Programs</p>
            </div>

            <div className="bg-white rounded-2xl border border-slate-200 p-6 shadow-sm">
              <div className="flex items-center gap-3 mb-2">
                <Target className="w-6 h-6 text-[#1E3A8A]" />
                <h3 className="font-bold text-2xl text-[#1A1A1A]">{stateData.avgScore}</h3>
              </div>
              <p className="text-sm text-slate-600">Avg. Score Range</p>
            </div>

            <div className="bg-white rounded-2xl border border-slate-200 p-6 shadow-sm">
              <div className="flex items-center gap-3 mb-2">
                <TrendingUp className="w-6 h-6 text-[#F59E0B]" />
                <h3 className="font-bold text-2xl text-[#1A1A1A]">92%</h3>
              </div>
              <p className="text-sm text-slate-600">StudyBuddy Pass Rate</p>
            </div>
          </div>
        </div>
      </section>

      {/* Top Nursing Schools */}
      <section className="py-20 bg-slate-50">
        <div className="mx-auto max-w-7xl px-4 sm:px-6 lg:px-8">
          <div className="text-center mb-12">
            <h2 className="text-3xl font-bold text-[#1A1A1A] mb-4">
              Top Nursing Schools in {stateData.name}
            </h2>
            <p className="text-lg text-slate-600">
              Students from these programs use StudyBuddy to pass the TEAS 7
            </p>
          </div>

          <div className="grid sm:grid-cols-2 lg:grid-cols-3 gap-6">
            {stateData.schools.map((school, index) => (
              <div
                key={index}
                className="bg-white rounded-2xl border border-slate-200 p-6 shadow-sm hover:shadow-lg hover:border-[#20B2AA] transition-all"
              >
                <div className="flex items-start gap-4">
                  <div className="w-12 h-12 rounded-xl bg-[#20B2AA]/10 flex items-center justify-center shrink-0">
                    <BookOpen className="w-6 h-6 text-[#20B2AA]" />
                  </div>
                  <div>
                    <h3 className="font-bold text-[#1A1A1A] mb-1">{school}</h3>
                    <p className="text-sm text-slate-500">TEAS 7 Required</p>
                  </div>
                </div>
              </div>
            ))}
          </div>
        </div>
      </section>

      {/* Why StudyBuddy for State */}
      <section className="py-20 bg-white">
        <div className="mx-auto max-w-7xl px-4 sm:px-6 lg:px-8">
          <div className="text-center mb-12">
            <h2 className="text-3xl font-bold text-[#1A1A1A] mb-4">
              Why {stateData.name} Students Choose StudyBuddy
            </h2>
          </div>

          <div className="grid md:grid-cols-3 gap-8">
            <div className="bg-slate-50 rounded-2xl p-8">
              <div className="w-14 h-14 rounded-2xl bg-[#20B2AA]/10 flex items-center justify-center mb-6">
                <Check className="w-7 h-7 text-[#20B2AA]" />
              </div>
              <h3 className="text-xl font-bold text-[#1A1A1A] mb-3">State-Specific Prep</h3>
              <p className="text-slate-600">
                Tailored content that matches {stateData.name} nursing program requirements and score expectations.
              </p>
            </div>

            <div className="bg-slate-50 rounded-2xl p-8">
              <div className="w-14 h-14 rounded-2xl bg-[#1E3A8A]/10 flex items-center justify-center mb-6">
                <Target className="w-7 h-7 text-[#1E3A8A]" />
              </div>
              <h3 className="text-xl font-bold text-[#1A1A1A] mb-3">92% Pass Rate</h3>
              <p className="text-slate-600">
                Our AI-powered system has helped thousands of {stateData.name} students pass on their first try.
              </p>
            </div>

            <div className="bg-slate-50 rounded-2xl p-8">
              <div className="w-14 h-14 rounded-2xl bg-[#F59E0B]/10 flex items-center justify-center mb-6">
                <Users className="w-7 h-7 text-[#F59E0B]" />
              </div>
              <h3 className="text-xl font-bold text-[#1A1A1A] mb-3">100% Pass Guarantee*</h3>
              <p className="text-slate-600">
                Complete the course and don't pass? Get a full refund or 60 free days. <Link href="/refunds" className="text-[#20B2AA] underline hover:text-[#18968F]">View policy</Link>
              </p>
            </div>
          </div>
        </div>
      </section>

      {/* CTA Section */}
      <section className="py-20 bg-gradient-to-br from-[#20B2AA] to-[#1E3A8A]">
        <div className="mx-auto max-w-4xl px-4 text-center">
          <h2 className="text-3xl md:text-4xl font-bold text-white mb-6">
            Ready to Ace Your {stateData.name} Nursing School Application?
          </h2>
          <p className="text-xl text-blue-50 mb-10">
            Join hundreds of {stateData.name} students who passed with StudyBuddy
          </p>
          <div className="flex flex-col sm:flex-row gap-4 justify-center">
            <Link
              href="/diagnostic"
              className="inline-flex items-center justify-center px-8 py-4 rounded-2xl bg-white text-[#20B2AA] font-bold shadow-lg hover:bg-slate-50 hover:scale-105 transition-all"
            >
              Start Free Diagnostic
            </Link>
            <Link
              href="/#pricing"
              className="inline-flex items-center justify-center px-8 py-4 rounded-2xl bg-transparent border-2 border-white text-white font-bold hover:bg-white/10 transition-all"
            >
              View Pricing
            </Link>
          </div>
        </div>
      </section>

      {/* FOOTER */}
      <footer className="bg-[#1A1A1A] text-white py-16">
        <div className="mx-auto max-w-7xl px-4 sm:px-6 lg:px-8">
          <div className="grid grid-cols-1 md:grid-cols-2 lg:grid-cols-4 gap-12 mb-12">
            
            {/* Company Info */}
            <div>
              <div className="flex items-center gap-2 mb-4">
                <div className="w-8 h-8 rounded-lg bg-[#20B2AA] flex items-center justify-center">
                  <span className="text-white font-bold text-lg">S</span>
                </div>
                <span className="text-xl font-bold">StudyBuddy</span>
              </div>
              <p className="text-slate-400 text-sm leading-relaxed mb-4">
                AI-powered TEAS 7 prep built by PhD & DNP nursing educators with 75+ years of combined experience. Pass guaranteed.
              </p>
              <p className="text-slate-500 text-xs mb-2">
                © 2025 EdExpert LLC. All rights reserved.
              </p>
              <p className="text-slate-600 text-[10px] leading-relaxed max-w-md">
                TEAS® is a registered trademark of the Assessment Technologies Institute, which is unaffiliated, not a sponsor, or associated with StudyBuddy.
              </p>
            </div>

            {/* Product Links */}
            <div>
              <h4 className="text-sm font-bold uppercase tracking-wider text-slate-300 mb-4">Product</h4>
              <ul className="space-y-3">
                <li>
                  <Link href="/diagnostic" className="text-slate-400 hover:text-[#20B2AA] transition-colors text-sm">
                    Free Diagnostic Test
                  </Link>
                </li>
                <li>
                  <Link href="/#pricing" className="text-slate-400 hover:text-[#20B2AA] transition-colors text-sm">
                    Pricing
                  </Link>
                </li>
                <li>
                  <Link href="/states" className="text-slate-400 hover:text-[#20B2AA] transition-colors text-sm">
                    State Requirements
                  </Link>
                </li>
                <li>
                  <a href="https://learn.studybuddy.live/about-studybuddy?site_template_id=67e1717114d4688062090ad2" className="text-slate-400 hover:text-[#20B2AA] transition-colors text-sm" target="_blank" rel="noopener">
                    About Us
                  </a>
                </li>
              </ul>
            </div>

            {/* Legal Links */}
            <div>
              <h4 className="text-sm font-bold uppercase tracking-wider text-slate-300 mb-4">Legal</h4>
              <ul className="space-y-3">
                <li>
                  <Link href="/privacy-policy" className="text-slate-400 hover:text-[#20B2AA] transition-colors text-sm">
                    Privacy Policy
                  </Link>
                </li>
                <li>
                  <Link href="/terms-and-conditions" className="text-slate-400 hover:text-[#20B2AA] transition-colors text-sm">
                    Terms & Conditions
                  </Link>
                </li>
                <li>
                  <Link href="/cookie-policy" className="text-slate-400 hover:text-[#20B2AA] transition-colors text-sm">
                    Cookie Policy
                  </Link>
                </li>
                <li>
                  <Link href="/refunds" className="text-slate-400 hover:text-[#20B2AA] transition-colors text-sm">
                    Refund Policy
                  </Link>
                </li>
              </ul>
            </div>

            {/* Support */}
            <div>
              <h4 className="text-sm font-bold uppercase tracking-wider text-slate-300 mb-4">Support</h4>
              <ul className="space-y-3">
                <li>
                  <a href="https://learn.studybuddy.live/contact-us?site_template_id=67e1717114d4688062090ad2" className="text-slate-400 hover:text-[#20B2AA] transition-colors text-sm" target="_blank" rel="noopener">
                    Contact Us
                  </a>
                </li>
                <li>
                  <a href="mailto:support@studybuddy.live" className="text-slate-400 hover:text-[#20B2AA] transition-colors text-sm">
                    support@studybuddy.live
                  </a>
                </li>
              </ul>
            </div>
          </div>
        </div>
      </footer>
    </main>
  );
}