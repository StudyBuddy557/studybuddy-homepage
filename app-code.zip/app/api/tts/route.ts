import { NextRequest, NextResponse } from 'next/server';
import OpenAI from 'openai';

const openai = new OpenAI({
  apiKey: process.env.OPENAI_API_KEY
});

export async function POST(request: NextRequest) {
  try {
    const { text, voice = 'onyx' } = await request.json();

    if (!text) {
      return NextResponse.json({ error: 'Text is required' }, { status: 400 });
    }

    console.log('🎙️ Generating TTS for:', text.substring(0, 50));

    const mp3 = await openai.audio.speech.create({
      model: 'tts-1-hd',
      voice: voice,
      input: text,
      speed: 0.95
    });

    const buffer = Buffer.from(await mp3.arrayBuffer());

    console.log('✅ TTS generated:', buffer.length, 'bytes');

    return new NextResponse(buffer, {
      headers: {
        'Content-Type': 'audio/mpeg',
        'Content-Length': buffer.length.toString(),
        'Cache-Control': 'public, max-age=31536000, immutable'
      }
    });

  } catch (error) {
    console.error('❌ TTS API Error:', error);
    return NextResponse.json({ error: 'TTS generation failed' }, { status: 500 });
  }
}
